<template>
  #if($TITLE_ICON)
    #if($SIZE$)
  <PopupBox title="$TITLE_ICON" size="$SIZE" @clickClose="clickClose"></PopupBox>
    #else
  <PopupBox title="$TITLE_ICON" @clickClose="clickClose"></PopupBox>
    #end
  #else
    #if($SIZE)
  <PopupBox size="$SIZE" @clickClose="clickClose"></PopupBox>
    #else
  <PopupBox @clickClose="clickClose"></PopupBox>
    #end
  #end
</template>

<script>
export default {
  props: ['config'],
  data() {
    return {}
  },
  methods: {
    clickClose() {
     this.\$emit('clickClose')
    }
  }
}
</script>

<style scoped lang="scss">
::v-deep .popupContent.popupContent {
  .main {
  }
}
</style>
