<template>
  <div class="$NAME"></div>
</template>

<script>
export default {
  name: '$NAME',
  props: [''],
  components: {},
  data() {
    return {}
  },
  created() {},
  mounted() {},
  beforeDestroy() {},
  computed: {},
  watch: {},
  methods: {}
}
</script>

<style lang="scss" scoped>
.$NAME {}
</style>