import Vue from 'vue'
import VueRouter from 'vue-router'
// import sensors from '../utils/sensors'
import lotteryNumber from '../views/index/index.vue'
Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    component: lotteryNumber
  }
]

const router = new VueRouter({
  routes
})

router.beforeEach((to, from, next) => {
  next()
})

router.afterEach((to, from) => {
  // Vue.nextTick(() => {
  //   sensors.quick('autoTrackSinglePage', {
  //     activity_name: '靓号摇摇乐'
  //   })
  // })
})
export default router
