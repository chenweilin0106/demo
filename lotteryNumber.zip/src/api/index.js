import request from '../utils/request'
// 当页数据
export const getPageData = (data) => {
  return request({
    url: '/actserver/lottery-number/home',
    method: 'post',
    data: {
      ...data
    }
  })
}

// 开启摇摇乐
export const loadLottery = () => {
  return request({
    url: '/actserver/lottery-number/open',
    method: 'post'
  })
}

// 摇一摇
export const loadLotteryOne = () => {
  return request({
    url: '/actserver/lottery-number/shake',
    method: 'post'
  })
}

// 选取靓号
export const getBeautifulNumber = (data) => {
  return request({
    url: '/actserver/lottery-number/select',
    method: 'post',
    data
  })
}

// 赠送靓号
export const giveBeautifulNumber = (data) => {
  return request({
    url: '/actserver/lottery-number/give-friend',
    method: 'post',
    data
  })
}
