import Vue from 'vue'
import App from './App.vue'
// import router from './router'
import store from './store'
import { Overlay, Toast, CountDown } from 'vant'
import 'normalize.css'
import './styles/reset.scss'
// import Vconsole from 'vconsole'
// const vconsole = new Vconsole()
// Vue.use(vconsole)
// import sensors from './utils/sensors.js'
// Vue.prototype.$sensors = sensors
Vue.config.productionTip = false
Vue.use(Overlay)
Vue.use(Toast)
Vue.use(CountDown)
new Vue({
  // router,
  store,
  render: (h) => h(App)
}).$mount('#app')
