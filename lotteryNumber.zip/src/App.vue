<template>
  <div id="app">
    <Index />
  </div>
</template>

<script>
import Index from './views/index/index.vue'
export default {
  components: {
    Index
  },
  props: {},
  data() {
    return {}
  },
  computed: {},
  watch: {},
  created() {},
  methods: {}
}
</script>

<style scoped lang="scss"></style>
