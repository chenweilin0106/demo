<template>
  <div class="lotteryNumber">
    <!-- banner图 -->
    <div class="banner"></div>
    <!-- 活动规则 -->
    <div
      class="btn_rule"
      @click="
        show = true
        dialogType = 'rule'
      "
    >
      <span>活动规则</span>
    </div>
    <!-- 摇号机 -->
    <div class="Lottery">
      <!-- 我的靓号券 -->
      <div class="my_present"><img src="../../assets/img_lhq.png" alt="" />当前拥有的靓号券：{{ nums }}</div>
      <!-- 开启按钮 -->
      <div @click="clickStart" class="start_btn" :class="{ off_btn: lottery_status == 3 }">
        {{ lottery_status == 1 ? '开启摇号机' : lottery_status == 2 ? '摇一摇' : lottery_status == 4 ? '摇号次数已达上限' : '' }}
        <van-count-down v-if="lottery_status == 3" :time="lock_times * 1000" format="DD天HH:mm:ss后可开启" />
      </div>
      <!-- 消耗5000靓号券 -->
      <div class="present_number" v-if="lottery_status != 3">消耗{{ lottery_status == 1 ? '5000' : cost }}<img :src="require(`../../assets/${lottery_status == 1 ? 'img_lhq_small.png' : 'img_welfare.png'}`)" alt="" /></div>
      <!-- 靓号展示 -->
      <!-- showAnimate -->
      <ul class="animate_flex" v-if="showAnimate">
        <ScrollNum v-for="(num, idx) of numArr" :key="idx" as="li" :i="num" :delay="idx == 0 ? 0.5 : 0.5 * (idx + 1)" @handleAnimate="handleAnimate"></ScrollNum>
      </ul>
      <!-- v-else -->
      <div class="number_box" v-else>
        <ul>
          <li v-for="(item, index) in beautifulNumberArr" :key="index">
            {{ item }}
          </li>
        </ul>
        <!-- {{ this.beautifulNumber ? this.beautifulNumber : '??????' }} -->
      </div>
    </div>
    <!-- 靓号备选池 -->
    <div class="rewardPool">
      <div class="rewardPool_body">
        <div @click="getNumber(item.pretty_id, item.status)" class="rewardPool_item" :class="{ rewardPool_item_get: item.status == 1 || item.status == 2 }" v-for="(item, index) in list" :key="index">
          {{ item.status == 4 ? '?' : item.pretty_id }}
          <div class="award_icon" v-if="item.status != 1">
            <span>{{ item.status == 4 ? '摇号获得' : item.status == 2 ? '已选靓号' : '已失效' }}</span>
          </div>
        </div>
      </div>
      <div class="rewardPool_text" v-if="lottery_status === 2 || lottery_status === 4">
        <p>
          <img src="../../assets/icon_star.png" alt="" />
          {{
            list.some((item) => {
              item.status === 2
            })
              ? '恭喜获得靓号'
              : '点击选择靓号'
          }}<img src="../../assets/icon_star.png" alt="" />
        </p>
        <p>
          <van-count-down
            v-if="
              list.every((item) => {
                return item.status !== 2
              })
            "
            :time="count_down * 1000"
            format="请在有效期内选定靓号：DD天 HH:mm:ss"
          />
        </p>
      </div>
    </div>
    <van-overlay class-name="my_overlay" :show="show" @click="handleClosed" duration="0">
      <div class="wrapper" @click.stop="handleClosed">
        <div class="rule_block" v-if="dialogType === 'rule'">
          <div class="rule_title">规则说明</div>
          <div class="rule_content">
            <p>1.用户参与其他活动可获取靓号券，消耗5000张靓号券可在本活动中使用摇号机</p>
            <p>2.每次使用摇号机时，可摇取10个靓号，请在7天内选定自己想要的靓号，超时后将收回所有靓号且退回消耗的靓号券</p>
            <p>3.因选号超时导致退回靓号券，30天后方可重新摇号</p>
            <p>4.本期摇号机内号段共5种：ABCABC、AABBCC、ABCDCBA、AAAAAAX、ABCDEFX</p>
            <p>5.每周五将定期开放少量特价靓号，先到先得，特价靓号不受摇号机的号段限制，请提前在活动页面查看特惠预告</p>
            <p>6.每位玩家只能拥有1个靓号，如需更换靓号请联系客服</p>
          </div>
          <div class="rule_botton" @click.stop="handleClosed">我知道啦</div>
        </div>
        <div class="award_block" v-else>
          <div class="top_text" v-if="dialogType === 'canReceive'">
            <p>是否选择该靓号</p>
            <p>赠送的靓号将在7个工作日内发放请耐心等待</p>
          </div>
          <div class="top_text" v-if="dialogType === 'canLook'">
            <p>已拥有该靓号</p>
            <p>快去看看吧~</p>
          </div>
          <div class="top_text" v-if="dialogType === 'canGift'">
            <p>你已经拥有靓号了</p>
            <p>是否将此靓号赠送给好友？</p>
          </div>
          <div class="top_text" v-if="dialogType === 'setUid'">
            <p>请填写好友ID</p>
            <p>赠送的靓号将在7个工作日内发放请耐心等</p>
          </div>
          <div class="number_box" v-if="dialogType === 'canReceive'">
            {{ this.number }}
          </div>
          <input v-model.trim="uid" type="text" placeholder="请输入好友ID" class="friend_id" v-if="dialogType === 'setUid'" @click.stop />
          <div class="input_toast" v-if="inputInfo">*请输入正确的用户ID</div>
          <div class="bottom_button" v-if="dialogType === 'canReceive'">
            <div class="left_botton" @click.stop="handleClosed">取消</div>
            <div class="right_botton" @click.stop="confirmSelection">确认选择</div>
          </div>
          <div class="bottom_button" v-if="dialogType === 'canLook'">
            <div class="left_botton" @click.stop="handleClosed">知道了</div>
            <div class="right_botton" @click.stop="confirmSelection">去看看</div>
          </div>
          <div class="bottom_button" v-if="dialogType === 'canGift'">
            <div class="left_botton" @click.stop="handleClosed">我再想想</div>
            <div class="right_botton" @click.stop="confirmSelection">立即赠送</div>
          </div>
          <div class="bottom_button" v-if="dialogType === 'setUid'">
            <div class="right_botton" @click.stop="confirmSelection">立即赠送</div>
          </div>
        </div>
      </div>
    </van-overlay>
    <div class="bottom_text">
      <p>活动由本公司组织并提供奖品</p>
      <p>与苹果公司无关</p>
    </div>
  </div>
</template>

<script>
// 老虎机组件
import ScrollNum from '../../components/ScrollNum.vue'
// 导入接口
import {
  getPageData,
  loadLottery,
  // loadLotteryOne,
  getBeautifulNumber,
  giveBeautifulNumber
} from '../../api/index'
// 导入APP方法
import { callAppF, toUserMain } from '../../utils/toApp'
export default {
  name: 'lotteryNumber',
  components: {
    ScrollNum
  },
  props: {},
  data() {
    return {
      lottery_status: 2, // 1-摇号机未开启；2-已开启摇号机，可以摇一摇；3-摇号机被锁定；4-摇号次数已达上限
      count_down: 0, // lottery_status=2摇号机已开启时，显示的倒计时秒（单位秒）
      lock_times: 0, // 用户摇号机被锁时间（单位秒）
      nums: '0', // 靓号券数量
      is_pretty: false, // 用户自身是否为靓号
      surplus_num: 10, // 用户剩余可摇号次数
      cost: 0, // 摇号需要花费的钻石数量
      masonry: '0', // 用户剩余钻石数量
      list: [
        // 摇号备选池
        {
          pretty_id: 0, // 靓号id，0-表示空
          status: 4 // 靓号状态：1-未选中，2-已选择，4-空数据
        },
        {
          pretty_id: 0,
          status: 4
        },
        {
          pretty_id: 0,
          status: 4
        },
        {
          pretty_id: 0,
          status: 4
        },
        {
          pretty_id: 0,
          status: 4
        },
        {
          pretty_id: 0,
          status: 4
        },
        {
          pretty_id: 0,
          status: 4
        },
        {
          pretty_id: 0,
          status: 4
        },
        {
          pretty_id: 0,
          status: 4
        },
        {
          pretty_id: 0,
          status: 4
        }
      ],
      showAnimate: false,
      num: '',
      count: 0,
      // 获取靓号
      number: '',
      // 赠送好友的uid
      uid: '',
      // 遮盖控制
      show: false,
      // 输入框检验信息
      inputInfo: false,
      // 摇一摇获取靓号
      beautifulNumber: '??????',
      // 弹框样式 canReceive 点击靓号tk canLook去看看靓号tk
      dialogType: ''
    }
  },
  computed: {
    numArr() {
      const str = String(this.num)
      const arr = []
      for (let i = 0; i < str.length; i++) {
        arr.push(parseInt(str[i]))
      }
      return arr
    },
    beautifulNumberArr() {
      const str = String(this.beautifulNumber)
      if (str === '??????') return ['?', '?', '?', '?', '?', '?']
      const arr = []
      for (let i = 0; i < str.length; i++) {
        arr.push(parseInt(str[i]))
      }
      return arr
    }
  },
  watch: {},
  async created() {
    // 获取uid和token
    this.$store.commit('user/getUidAndAccess_token', window.location.search.substring(1))
    // await this.getPageData()
    // this.showAnimate = true
  },
  methods: {
    async handleAnimate() {
      this.count += 1
      console.log('count', this.count)
      if (this.count >= 6) {
        // console.log('handleAnimate')
        this.showAnimate = false
        this.beautifulNumber = this.num
        this.count = 0
        // await this.getPageData()
      }
    },
    // 监听页面呼出回调函数
    hiddenFn() {
      if (document.hidden) {
        // console.log('挂起');
        // 页面被挂起
      } else {
        // 页面呼出
        this.getPageData()
        document.removeEventListener('visibilitychange', this.hiddenFn)
      }
    },
    // 钻石充值弹框
    callAppF(num) {
      callAppF(num, this.hiddenFn)
    },
    // 弹框内---确认选择
    async confirmSelection() {
      if (this.dialogType == 'canReceive') {
        if (this.is_pretty) {
          this.dialogType = 'canGift'
        } else {
          const res = await this.getBeautifulNumber(this.number)
          if (res.errno == 0) {
            this.dialogType = 'canLook'
          } else {
            this.handleClosed()
          }
        }
      } else if (this.dialogType === 'canLook') {
        toUserMain(this.$store.getters.uid)
      } else if (this.dialogType === 'canGift') {
        this.dialogType = 'setUid'
      } else if (this.dialogType === 'setUid') {
        const reg = /^\d{5,9}$/
        if (reg.test(this.uid)) {
          this.inputInfo = false
          const res = await this.loadHandleNum()
          if (res.errno === -1) {
            this.$toast('该好友已有靓号，无法赠送')
          } else {
            this.beautifulNumber = ''
            this.handleClosed()
            this.$toast('赠送靓号申请已提交')
          }
        } else {
          this.inputInfo = true
        }
      }
    },
    // 点击获取靓号
    getNumber(num, status) {
      if (status == 1) {
        this.number = num
        if (this.is_pretty) {
          this.dialogType = 'canGift'
        } else {
          this.dialogType = 'canReceive'
        }
        this.show = true
      }
    },
    // 抽奖按钮
    async clickStart() {
      // const lotteryStatus = this.lottery_status
      // if (lotteryStatus === 1) {
      //   if (+this.nums < 5000) {
      //     return this.$toast('靓号券不足，无法开启')
      //   }
      //   await this.loadLottery()
      //   await this.getPageData()
      // } else if (+lotteryStatus === 2) {
      //   if (this.masonry < this.cost) {
      //     this.callAppF(this.cost - this.masonry)
      //     return
      //   }
      //   if (this.showAnimate) return
      //   this.showAnimate = true
      //   await this.loadLotteryOne()
      // }
      this.showAnimate = true
      this.loadLotteryOne()
    },
    // 关闭弹框
    async handleClosed() {
      this.show = false
      if (this.dialogType === 'canGift') {
        this.$toast('再次点击靓号可赠送好友')
      }
      if (this.dialogType !== 'rule') {
        await this.getPageData()
      }
      this.dialogType = ''
      this.uid = ''
    },
    // 封装赠送靓号接口
    async loadHandleNum() {
      const res = await giveBeautifulNumber({
        pretty_id: this.number,
        to_uid: this.uid
      })
      return res
    },
    // 封装获取靓号接口
    async getBeautifulNumber(prettyId) {
      const res = await getBeautifulNumber({
        pretty_id: prettyId
      })
      return res
    },
    // 封装摇一摇接口
    async loadLotteryOne() {
      this.num = new Array(6).fill(0).map((item, index) => {
        return Math.floor(Math.random() * 10)
      }).join('')
      // const res = await loadLotteryOne()
      // return res
    },
    // 封装开启摇摇乐接口
    async loadLottery() {
      await loadLottery()
    },
    // 封装页面数据接口
    async getPageData() {
      const res = await getPageData()
      if (res.errno !== 0) {
        this.$toast(res.errmsg)
      } else {
        this.pageData = res.data
      }
    }
  }
}
</script>

<style scoped lang="scss">
.animate_flex {
  display: flex;
  justify-content: space-evenly;
  align-items: center;
  position: absolute;
  top: 130px;
  left: 78px;
  width: 214px;
  height: 100px;
  overflow: hidden;
}
.lotteryNumber {
  padding-bottom: 30px;
}
// 倒计时
.van-count-down {
  font-size: 18px;
  font-weight: 600;
  color: #ffffff;
}
// 遮罩层
.my_overlay {
  .wrapper {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
    .award_block {
      position: relative;
      width: 300px;
      max-height: 300px;
      padding-top: 65px;
      background: url('../../assets/bg_pop.png') no-repeat;
      background-size: 100%;
      display: flex;
      flex-direction: column;
      align-items: center;
      border-radius: 20px;
      .top_text {
        p {
          text-align: center;
          color: #ffffff;
          letter-spacing: 1px;
        }
        p:nth-child(1) {
          font-size: 20px;
          font-weight: 600;
        }
        p:nth-child(2) {
          width: 210px;
          margin: 5px auto 0;
          font-size: 13px;
          line-height: 20px;
        }
      }
      .friend_id {
        margin-top: 10px;
        width: 232px;
        height: 41px;
        background: url('../../assets/img_input.png') no-repeat;
        line-height: 41px;
        background-size: 100%;
        font-size: 12px;
        padding-left: 11px;
        &::placeholder {
          position: relative;
          opacity: 0.5;
          font-size: 12px;
          font-family: PingFangSC-Regular, PingFang SC;
          color: #333333;
          letter-spacing: 1px;
        }
      }
      .input_toast {
        position: absolute;
        top: 185px;
        left: 35px;
        width: 230px;
        padding-top: 5px;
        color: #fd2f09;
        font-size: 10px;
        font-family: PingFangSC-Regular, PingFang SC;
      }
      .number_box {
        margin: 20px 0 0px;
        width: 162px;
        height: 42px;
        background: url('../../assets/img_lianghao.png') no-repeat;
        background-size: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 20px;
        font-weight: 600;
        color: #8e40dd;
        letter-spacing: 1px;
      }
      .bottom_button {
        margin-top: 40px;
        margin-bottom: 20px;
        width: 100%;
        display: flex;
        justify-content: space-evenly;
        align-items: center;
        .left_botton,
        .right_botton {
          width: 120px;
          height: 40px;
          display: flex;
          justify-content: center;
          align-items: center;
          font-size: 16px;
          font-weight: 600;
          color: #fefefe;
          letter-spacing: 1px;
        }
        .left_botton {
          background: url('../../assets/btn_cancel.png') no-repeat;
          background-size: 100%;
        }
        .right_botton {
          background: url('../../assets/btn_confirm.png') no-repeat;
          background-size: 100%;
        }
      }
    }
    .rule_block {
      width: 300px;
      height: 591px;
      background: url('../../assets/bg_pop_rule.png') no-repeat;
      background-size: 100%;
      display: flex;
      flex-direction: column;
      align-items: center;
      .rule_title {
        margin: 70px 0 8px;
        font-size: 20px;
        font-weight: 600;
        color: #ffffff;
        letter-spacing: 1px;
      }
      .rule_content {
        width: 245px;
        font-size: 13px;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 500;
        color: #ffffff;
        line-height: 21px;
        letter-spacing: 1px;
        p {
          margin-bottom: 10px;
        }
      }
      .rule_botton {
        margin-top: 5px;
        width: 120px;
        height: 40px;
        background: linear-gradient(180deg, #fe5d99 0%, #ff8193 100%);
        border-radius: 20px;
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 16px;
        font-weight: 600;
        color: #fefefe;
        letter-spacing: 1px;
      }
    }
  }
}
// banner图
.banner {
  width: 100%;
  height: 236px;
  background: url('../../assets/bg.png') no-repeat;
  background-size: 100% 100%;
}
// 活动规则
.btn_rule {
  position: fixed;
  z-index: 999;
  right: 0;
  top: 90px;
  width: 23px;
  height: 60px;
  background: url('../../assets/btn_rule.png') no-repeat;
  background-size: 100% 100%;
  font-size: 11px;
  font-weight: 600;
  color: #e95096;
  padding-left: 5px;
  span {
    display: block;
    transform: scale(0.8);
  }
}
// 摇号机
.Lottery {
  position: relative;
  width: 100%;
  height: 350px;
  background: url('../../assets/img_yhj.png') no-repeat;
  background-size: 100%;
  margin-top: -75px;
  overflow: hidden;
  // 拥有的靓号券
  .my_present {
    color: #382c64;
    font-size: 12px;
    font-weight: 600;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    margin-top: 20px;
    padding-left: 85px;
    img {
      width: 40px;
      margin-right: 3px;
    }
  }
  // 开启按钮
  .start_btn {
    position: absolute;
    bottom: 50px;
    left: 75px;
    width: 225px;
    height: 60px;
    background: url('../../assets/img_btn.png') no-repeat;
    background-size: 100%;
    font-size: 21px;
    font-weight: 600;
    color: #ffffff;
    display: flex;
    justify-content: center;
    padding-top: 5px;
    letter-spacing: 3px;
  }
  // 按钮锁定
  .off_btn {
    padding-top: 10px !important;
    font-size: 18px !important;
    background: url('../../assets//img_btn_dis.png') no-repeat !important;
    background-size: 100% !important;
    letter-spacing: 0;
    font-weight: normal !important;
  }
  // 消耗靓号券
  .present_number {
    position: absolute;
    width: 100%;
    bottom: 15px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 16px;
    color: #fff;
    img {
      height: 24px;
      margin-left: 5px;
    }
  }
  // 靓号
  .number_box {
    position: absolute;
    top: 150px;
    left: 78px;
    width: 214px;
    height: 60px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 40px;
    font-weight: 600;
    color: #ffffff;
    ul {
      width: 100%;
      display: flex;
      justify-content: space-evenly;
      align-items: center;
      padding-left: 4px;
      li {
        display: flex;
        justify-content: center;
        align-items: center;
      }
    }
  }
}
// 靓号备选池
.rewardPool {
  width: 345px;
  margin: 14px auto 0;
  background: url('../../assets/bg_bxc.png') no-repeat;
  background-size: 100%;
  overflow: hidden;
  border-radius: 15px;
  .rewardPool_body {
    margin-top: 60px;
    width: 100%;
    display: flex;
    justify-content: space-evenly;
    flex-wrap: wrap;
    .rewardPool_item {
      position: relative;
      width: 60px;
      height: 60px;
      margin-bottom: 10px;
      background: url('../../assets/bg_box.png') no-repeat;
      background-size: 100% 100%;
      background-position: center;
      display: flex;
      justify-content: center;
      align-items: center;
      font-size: 12px;
      color: #fff;
      font-weight: 600;
      // 摇号获得
      .award_icon {
        position: absolute;
        top: 45px;
        left: 6px;
        width: 48px;
        height: 15px;
        font-size: 12px;
        font-family: PingFangSC-Regular, PingFang SC;
        color: #ffffff;
        background: linear-gradient(180deg, #ff4892 0%, #ff6da8 100%);
        border-radius: 3px;
        border-image: linear-gradient(180deg, rgba(253, 221, 248, 1), rgba(240, 139, 203, 1)) 1 1;
        > span {
          display: block;
          transform: scale(0.8);
        }
      }
      // 已选靓号
      .rewardPool_item_get {
        background: url('../../assets/img_box_sel.png') no-repeat !important;
        background-size: 100% 100% !important;
        background-position: center !important;
        .award_icon {
          background: #7b4bf4 !important;
          border: 1px solid #fdf6d6 !important;
        }
      }
      // 失效
      .rewardPool_item_fail {
        background: url('../../assets/img_box_dis.png') no-repeat !important;
        background-size: 100% 100% !important;
        background-position: center !important;
        .award_icon {
          background: linear-gradient(180deg, #9482c2 0%, #b0a4ce 100%) !important;
          border: 1px solid #ffffff !important;
        }
      }
    }
  }
}
// 备选池文本
.rewardPool_text {
  width: 250px;
  height: 50px;
  background: #6c8cff;
  border-radius: 13px;
  margin: 9px auto 31px;
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
  align-items: center;
  p {
    color: #ffffff;
    letter-spacing: 1px;
  }
  p:nth-child(1) {
    display: flex;
    justify-content: center;
    align-items: center;
    img {
      width: 16px;
      margin: 0 5px;
    }
    font-size: 16px;
    font-weight: 600;
  }
  p:nth-child(2) {
    display: flex;
    justify-content: center;
    align-items: center;
    .van-count-down {
      font-size: 10px;
      font-weight: 500;
    }
  }
}
// 底部文本
.bottom_text {
  margin-top: 30px;
  p {
    font-size: 14px;
    text-align: center;
    color: #fff;
  }
}
</style>
